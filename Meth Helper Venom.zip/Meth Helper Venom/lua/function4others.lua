_G.CookFaster = _G.CookFaster or {}
CookFaster.options_menu = "CookFaster_menu"
CookFaster.ModPath = ModPath
CookFaster.SaveFile = CookFaster.SaveFile or SavePath .. "CookFaster.txt"
CookFaster.ModOptions = CookFaster.ModPath .. "menus/modoptions.txt"
CookFaster.settings = CookFaster.settings or {}

function CookFaster:Reset()
	self.settings = {
		Bile_Coming = true,  -- Только включение/выключение быстрой варки
	}
	self:Save()
end

function CookFaster:Load()
	local file = io.open(self.SaveFile, "r")
	if file then
		for key, value in pairs(json.decode(file:read("*all"))) do
			self.settings[key] = value
		end
		file:close()
	else
		self:Reset()
	end
end

function CookFaster:Save()
	local file = io.open(self.SaveFile, "w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

CookFaster:Load()

Hooks:Add("LocalizationManagerPostInit", "CookFaster_loc", function(loc)
	LocalizationManager:add_localized_strings({
		["CookFaster_menu_title"] = "Быстрая готовка Мета",
		["CookFaster_menu_desc"] = "",
		["CookFaster_menu_Bile_Coming_title"] = "Мгновенная варка мета",
		["CookFaster_menu_Bile_Coming_desc"] = "Вкл/Выкл мгновенную варку мета (0.1 секунда). Другие таймеры: 3 секунды.",
	})
end)

Hooks:Add("MenuManagerSetupCustomMenus", "CookFasterOptions", function( menu_manager, nodes )
	MenuHelper:NewMenu( CookFaster.options_menu )
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "CookFasterOptions", function( menu_manager, nodes )
	MenuCallbackHandler.CookFaster_menu_Bile_Coming_callback = function(self, item)
		CookFaster.settings.Bile_Coming = item:value() == "on" and true or false
		CookFaster:Save()
	end
	
	MenuHelper:AddToggle({
		id = "CookFaster_menu_Bile_Coming_callback",
		title = "CookFaster_menu_Bile_Coming_title",
		callback = "CookFaster_menu_Bile_Coming_callback",
		value = CookFaster.settings.Bile_Coming,
		menu_id = CookFaster.options_menu,  
		help_id = "CookFaster_menu_Bile_Coming_desc"
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "CookFasterOptions", function(menu_manager, nodes)
	nodes[CookFaster.options_menu] = MenuHelper:BuildMenu( CookFaster.options_menu )
	MenuHelper:AddMenuItem(nodes["blt_options"], CookFaster.options_menu, "CookFaster_menu_title", "CookFaster_menu_desc")
end)